
function submitAnswer(ans) {
     if (ans===1) {
          y = document.getElementById("answer").value
          yy=y.toUpperCase();
          
          if (yy === "B") {
               alert("You are right!")
               
          }
          else {
               alert("You are wrong!")
          }
          
     }
    
     if (ans===2) {
          y = document.getElementById("answer1").value
          yy = y.toUpperCase();
          if (yy=== "C") {
               alert("You are right!")
          }
          else {
               alert("You are wrong!")
          }
     }
     if (ans===3) {
          y = document.getElementById("answer2").value
          yy = y.toUpperCase();
          if (yy=== "D") {
               alert("You are right!")
               
          }
          else {
               alert("You are wrong!")
          }
     }
     if (ans===4) {
          y = document.getElementById("answer3").value
          yy = y.toUpperCase();
          if (yy=== "C") {
               alert("You are right!")
          }
          else {
               alert("You are wrong!")
          }
     }
     if (ans===5) {
          y = document.getElementById("answer4").value
          yy = y.toUpperCase();
          if (yy=== "B") {
               alert("You are right!")
          }
          else {
               alert("You are wrong!")
          }
     }
     if (ans===6) {
          y = document.getElementById("answer5").value
          yy = y.toUpperCase();
          if (yy=== "C") {
               alert("You are right!")
          }
          else {
               alert("You are wrong!")
          }
     }
     if (ans===7) {
          y = document.getElementById("answer6").value
          yy = y.toUpperCase();
          if (yy=== "A") {
               alert("You are right!")
          }
          else {
               alert("You are wrong!")
          }
     }
     if (ans===8) {
          y = document.getElementById("answer7").value
          yy = y.toUpperCase();
          if (yy=== "B") {
               alert("You are right!")
          }
          else {
               alert("You are wrong!")
          }
     }
     if (ans===9) {
          y = document.getElementById("answer8").value
          yy = y.toUpperCase();
          if (yy=== "D") {
               alert("You are right!")
          }
          else {
               alert("You are wrong!")
          }
     }
     if (ans===10) {
          y = document.getElementById("answer9").value
          yy = y.toUpperCase();
          if (yy=== "C") {
               alert("You are right!")
          }
          else {
               alert("You are wrong!")
          }
     }
     if (ans===11) {
          y = document.getElementById("answer10").value
          yy = y.toUpperCase();
          if (yy=== "B") {
               alert("You are right!")
          }
          else {
               alert("You are wrong!")
          }
     }
     if (ans===12) {
          y = document.getElementById("answer11").value
          yy = y.toUpperCase();
          if (yy=== "D") {
               alert("You are right!")
          }
          else {
               alert("You are wrong!")
          }
     }
     if (ans===13) {
          y = document.getElementById("answer12").value
          yy = y.toUpperCase();
          if (yy=== "B") {
               alert("You are right!")
          }
          else {
               alert("You are wrong!")
          }
     }
     if (ans===14) {
          y = document.getElementById("answer13").value
          yy = y.toUpperCase();
          if (yy=== "C") {
               alert("You are right!")
          }
          else {
               alert("You are wrong!")
          }
     }
     if (ans===15) {
          y = document.getElementById("answer14").value
          yy = y.toUpperCase();
          if (yy=== "A") {
               alert("You are right!")
          }
          else {
               alert("You are wrong!")
          }
     }
     if (ans===16) {
          y = document.getElementById("answer15").value
          yy = y.toUpperCase();
          if else (yy=== "C") {
               alert("You are right!")
          }
          else {
               alert("You are wrong!")
          }
     }
}

